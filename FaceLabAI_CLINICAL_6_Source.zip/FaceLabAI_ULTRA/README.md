# FACE LAB AI 6.0 — Clinical Visual Studio

Android visual simulation + risk-awareness training app.

## v6 modules
- Photo Sculpt Lab: local touch-based visual warp tools (volume, slim, lift, smooth), undo/redo, before/after, save/share
- Needle Awareness Trainer: draggable virtual syringe, photo/mannequin background, calibrated educational risk zones, warning beep + haptic feedback, layer overlays, training contact log and risk-avoidance score
- Layered Anatomy Atlas: schematic vessels / nerves / muscles for anatomy awareness
- Safety Center: urgent red-flag recognition + short safety quiz
- Local photo processing, no account required, core functions work offline

## Safety boundary
This app is not an injection guide and does not validate clinical correctness. It deliberately does not provide injection entry points, needle depth, recommended angles, doses, treatment plans, or patient-specific procedural instructions. Lack of an alert in the trainer does not mean a location is safe. Photo Sculpt is a visual effect and does not predict treatment or surgical outcomes.

Package: `com.facelab.ai`  
Version: `6.0.0`  
Minimum Android: 10 (API 29)  
Target: Android API 35
