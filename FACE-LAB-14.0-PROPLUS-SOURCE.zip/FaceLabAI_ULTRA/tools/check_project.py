from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
required=['home','sim','mapping','academy','safety','cases','compare','progress','profile','simCameraInput','simGalleryInput','simEffectCanvas','mapCanvas','modal']
missing=[x for x in required if f'id="{x}"' not in html]
if missing:
    raise SystemExit('Missing DOM id(s): '+', '.join(missing))
for token in ['FACE LAB PRO+ 14.0','Interactive Simulation Lab','Technique Coach','openNativeCamera','applyMapTemplate','fillLabel','fl14_sim','AndroidBridge']:
    if token not in html:
        raise SystemExit('Missing feature token: '+token)
print('FACE LAB PRO+ 14.0 project check: OK')
