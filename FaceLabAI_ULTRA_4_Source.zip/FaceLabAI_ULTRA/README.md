# FACE LAB 8.0 Commercial

Offline Android aesthetic-learning studio focused on visual simulation, anatomy/safety education, case review, knowledge checks, and local progress tracking.

Creator: Dr. Amin Pour Esmaeil

## Important scope
This app is educational. It does not provide real injection points, dose, needle depth, angle, injection path, diagnosis, or treatment planning, and it does not replace supervised clinical training.

## Android
- Package: `com.facelab.ai`
- Version: `8.0` / versionCode `12`
- minSdk: 29
- targetSdk: 35
- Offline WebView UI
