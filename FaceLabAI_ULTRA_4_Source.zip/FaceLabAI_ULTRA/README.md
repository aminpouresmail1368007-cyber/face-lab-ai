# FACE LAB PRO+ 20.0

Android educational facial visualization simulator.

## 20.0 highlights
- Personal-photo face mapping using on-device Android face detection (no network upload).
- Dynamic training overlays aligned to the detected face.
- Interactive 3D Explore tilt view for visual inspection.
- Stronger cumulative visual simulation after successful virtual interactions.
- InShot-style draggable Before/After comparison slider.
- Press-and-hold on the face to momentarily reveal BEFORE.
- Academy lessons now open into full lesson sheets with checkpoints.
- Installer-source security status for CafeBazaar / Myket / Google Play readiness.
- Package remains `com.facelab.ai`; versionCode 200, versionName 20.0.

Important: FACE LAB is an educational visual simulator. It does not provide real injection depth, angle, dose, or procedural instructions.
