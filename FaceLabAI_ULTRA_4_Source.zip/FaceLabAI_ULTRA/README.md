# FACE LAB AI 4.0 — Android

نسخه‌ی آفلاین و نصب‌شونده‌ی Android برای شبیه‌سازی تصویری زیبایی صورت.

## امکانات نسخه 4
- رابط کاربری فارسی و بسیار ساده با مسیر سه‌مرحله‌ای: عکس → انتخاب حالت → مقایسه
- Filler Preview: لب، گونه، چانه و فک
- Botox Preview: پیشانی، خط اخم و کنار چشم
- Contour Preview: فک، چانه و نمای غبغب
- اسلایدر Before / Preview لمسی
- سه شدت ملایم، طبیعی و واضح + کنترل دستی
- Visual Face Guide و خطوط تقسیم‌بندی صورت
- Anatomy View آموزشی
- انتخاب عکس از گالری یا دوربین Android
- ذخیره نتیجه در Pictures/FaceLabAI
- اشتراک مستقیم خروجی از Android
- پردازش اصلی آفلاین و بدون نیاز به ساخت حساب
- Self Test داخلی برای کنترل هسته رابط

## نکته علمی
این برنامه نتیجه درمان را پیش‌بینی نمی‌کند و دوز، نقطه یا الگوی تزریق ارائه نمی‌دهد. شبیه‌سازی‌ها صرفاً تقریبی و تصویری هستند.

## ساخت APK با GitHub Actions
1. کل محتویات این پوشه را در ریشه یک Repository در GitHub قرار دهید.
2. تب Actions را باز کنید.
3. Workflow با نام `Build FACE LAB AI APK` را اجرا کنید یا یک Push روی main انجام دهید.
4. پس از اتمام Build، Artifact با نام `FACE-LAB-AI-4.0-APK` را دانلود کنید.
5. داخل ZIP خروجی، فایل `FACE-LAB-AI-4.0.apk` قابل نصب روی Android است.

Package: `com.facelab.ai`
Version: `4.0.0`
Minimum Android: 10 (API 29)
Target: Android API 35
