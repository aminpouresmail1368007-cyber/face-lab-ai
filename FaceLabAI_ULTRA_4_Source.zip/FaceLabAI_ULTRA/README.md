# FACE LAB AI 5.0 — Clinical Atlas

Android aesthetic visualization + interactive clinical education app.

## New in v5
- Clinical Atlas with touch-based facial region trainer
- Broad treatment-region education for filler / botulinum toxin / contour
- Risk-awareness overlays and sensitive-anatomy summaries
- Complication red-flag recognition
- Pre-treatment safety review and product-literacy cards
- No injection point, needle depth, angle, dose, or procedural technique

## Existing features
- Filler / Botox / Contour visual preview
- Before / Preview slider
- Camera and gallery photo import
- Anatomy View
- Offline local visual processing
- Save/share result

## Safety scope
This app is an educational visualization aid, not a treatment plan or injection guide. It deliberately does not provide exact injection entry points, depths, angles, doses, or procedural steps. Injectable aesthetic procedures should be performed only by appropriately trained and licensed professionals using product labeling and local clinical protocols.

Package: `com.facelab.ai`
Version: `5.0.0`
Minimum Android: 10 (API 29)
Target: Android API 35
