# FACE LAB — Clinical Academy 7.3
**Creator:** Dr. Amin Pouresmail / دکتر امین پوراسماعیل

Offline Android visual simulator for aesthetic education, structured assessment and safety awareness.

## Modules
- Photo Sculpt Lab
- Needle Awareness Trainer with visual risk alerts
- Aesthetic Mapping Studio with proportional reference lines and 10 region review cards
- Layered Anatomy Atlas
- Safety Center + Quiz
- Clinical Workflow Guide with 8 safety gates
- Local case notes and assessment checklist
- Active syringe plunger with live visual-response simulation
- 10 broad training-region targets with contextual coaching
- Target-match HUD, resettable visual response and risk-layer feedback

## Safety scope
This build intentionally does **not** provide injection entry points, doses, needle/cannula depth, angles, product-specific injection patterns, or step-by-step injection technique. Mapping lines are proportion and assessment references, not injection lines. The app is not a substitute for supervised hands-on clinical training, licensure, local protocols, or product-specific official instructions.

- Package: `com.facelab.ai`
- Version: 7.3.0
- Min Android: API 29
- Target Android: API 35


## 7.3 hotfix
- Fixed startup splash hang: mapping JavaScript is now inside the runtime script, not the CSS block.
- Added a splash fail-safe.
- Updated visible version labels.
