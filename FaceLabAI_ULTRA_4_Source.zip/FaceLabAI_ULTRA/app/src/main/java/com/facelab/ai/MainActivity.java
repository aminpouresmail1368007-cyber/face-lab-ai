package com.facelab.ai;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.media.FaceDetector;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private static final int NATIVE_CAMERA_REQUEST = 7102;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 9, 12));

        webView = new WebView(this);
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep FACE LAB's
        // bottom navigation above the system navigation/gesture area.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottomInset);
            return insets;
        });
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(false);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.rgb(5, 9, 12));
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u == null ? "" : u.getScheme();
                return scheme != null && !scheme.equals("file") && !scheme.equals("about");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");

                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraOutputUri = createCameraOutputUri();
                if (cameraOutputUri != null) camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                if (params != null && params.isCaptureEnabled()) {
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                }

                try {
                    if (params != null && params.isCaptureEnabled() && cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(camera, FILE_CHOOSER_REQUEST);
                        return true;
                    }
                    Intent chooser = new Intent(Intent.ACTION_CHOOSER);
                    chooser.putExtra(Intent.EXTRA_INTENT, gallery);
                    chooser.putExtra(Intent.EXTRA_TITLE, "عکس گرفتن یا انتخاب از گالری");
                    if (cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "گالری یا دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private Uri createCameraOutputUri() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "FaceLab_Camera_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
            return getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == NATIVE_CAMERA_REQUEST) {
            if (resultCode == RESULT_OK && cameraOutputUri != null) {
                try (InputStream is = getContentResolver().openInputStream(cameraOutputUri); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                    if (is == null) throw new Exception("camera stream unavailable");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = is.read(buffer)) > 0) bos.write(buffer, 0, n);
                    String dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.FaceLabNativePhoto && window.FaceLabNativePhoto(" + JSONObject.quote(dataUrl) + ")", null);
                } catch (Exception e) {
                    Toast.makeText(this, "خواندن عکس دوربین انجام نشد", Toast.LENGTH_LONG).show();
                }
            }
            cameraOutputUri = null;
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
                if (cameraOutputUri != null) {
                    try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
                }
            } else if (cameraOutputUri != null) {
                result = new Uri[]{cameraOutputUri};
            }
        } else if (cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
        cameraOutputUri = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.FaceLab && FaceLab.handleAndroidBack ? FaceLab.handleAndroidBack() : 'not-handled'", value -> {
                if ("\"handled\"".equals(value)) return;
                if (webView.canGoBack()) webView.goBack();
                else MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String getVersion() { return "20.0"; }



        @JavascriptInterface
        public String detectFaceFromDataUrl(String dataUrl) {
            JSONObject out = new JSONObject();
            try {
                if (dataUrl == null || !dataUrl.contains(",")) {
                    out.put("found", false);
                    return out.toString();
                }
                String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
                int srcW = Math.max(2, bounds.outWidth);
                int srcH = Math.max(2, bounds.outHeight);

                int sample = 1;
                while (srcW / sample > 1200 || srcH / sample > 1600) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                opts.inPreferredConfig = Bitmap.Config.RGB_565;
                Bitmap decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                if (decoded == null) throw new Exception("decode failed");

                int w = decoded.getWidth();
                int h = decoded.getHeight();
                if ((w & 1) == 1) w -= 1; // FaceDetector requires even width.
                Bitmap scaled = decoded;
                if (w != decoded.getWidth()) {
                    scaled = Bitmap.createScaledBitmap(decoded, w, h, true);
                    decoded.recycle();
                }
                Bitmap rgb565 = scaled.getConfig() == Bitmap.Config.RGB_565 ? scaled : scaled.copy(Bitmap.Config.RGB_565, false);
                if (rgb565 != scaled) scaled.recycle();

                FaceDetector detector = new FaceDetector(rgb565.getWidth(), rgb565.getHeight(), 1);
                FaceDetector.Face[] faces = new FaceDetector.Face[1];
                int count = detector.findFaces(rgb565, faces);
                out.put("width", rgb565.getWidth());
                out.put("height", rgb565.getHeight());
                if (count > 0 && faces[0] != null) {
                    PointF mid = new PointF();
                    faces[0].getMidPoint(mid);
                    float eye = faces[0].eyesDistance();
                    out.put("found", eye > 0f);
                    out.put("midX", mid.x / rgb565.getWidth());
                    out.put("midY", mid.y / rgb565.getHeight());
                    out.put("eyeDistance", eye / rgb565.getWidth());
                    out.put("confidence", faces[0].confidence());
                } else {
                    out.put("found", false);
                }
                rgb565.recycle();
            } catch (Exception e) {
                try { out.put("found", false); out.put("error", "face_detection_failed"); } catch (Exception ignored) {}
            }
            return out.toString();
        }

        @JavascriptInterface
        public String getInstallSource() {
            try {
                PackageManager pm = getPackageManager();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    String pkg = pm.getInstallSourceInfo(getPackageName()).getInstallingPackageName();
                    return pkg == null ? "direct" : pkg;
                }
                String pkg = pm.getInstallerPackageName(getPackageName());
                return pkg == null ? "direct" : pkg;
            } catch (Exception e) {
                return "unknown";
            }
        }

        @JavascriptInterface
        public boolean isTrustedMarketInstall() {
            String src = getInstallSource();
            return "com.farsitel.bazaar".equals(src)
                    || "ir.mservices.market".equals(src)
                    || "com.android.vending".equals(src);
        }

        @JavascriptInterface
        public void openFrontCamera() {
            runOnUiThread(() -> {
                try {
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraOutputUri = createCameraOutputUri();
                    if (cameraOutputUri == null) { Toast.makeText(MainActivity.this, "امکان ساخت فایل عکس وجود ندارد", Toast.LENGTH_LONG).show(); return; }
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                    if (camera.resolveActivity(getPackageManager()) != null) startActivityForResult(camera, NATIVE_CAMERA_REQUEST);
                    else Toast.makeText(MainActivity.this, "برنامه دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "باز کردن دوربین انجام نشد", Toast.LENGTH_LONG).show(); }
            });
        }

        @JavascriptInterface
        public void alertFeedback(final String level) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    boolean danger = "danger".equalsIgnoreCase(level);
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            if (danger) vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 70, 190}, -1));
                            else vibrator.vibrate(VibrationEffect.createOneShot(55L, 110));
                        } else {
                            if (danger) vibrator.vibrate(new long[]{0, 120, 70, 190}, -1);
                            else vibrator.vibrate(55L);
                        }
                    }
                    ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, danger ? 95 : 55);
                    if (danger) {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 160);
                        new android.os.Handler(getMainLooper()).postDelayed(() -> tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 190), 230);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 520);
                    } else {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 130);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public boolean saveBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri != null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "در Pictures/FaceLab ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "ذخیره انجام نشد", Toast.LENGTH_LONG).show());
            return false;
        }

        @JavascriptInterface
        public boolean shareBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri == null) return false;
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "اشتراک نتیجه FACE LAB"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "اشتراک‌گذاری در دسترس نیست", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        private Uri persistDataUrl(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.contains(",")) return null;
                String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = requestedName;
                if (safeName == null || safeName.trim().isEmpty()) {
                    safeName = "FaceLab_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
                }
                if (!safeName.toLowerCase(Locale.US).endsWith(".png")) safeName += ".png";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) return null;
                    os.write(bytes);
                    os.flush();
                }
                return uri;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
