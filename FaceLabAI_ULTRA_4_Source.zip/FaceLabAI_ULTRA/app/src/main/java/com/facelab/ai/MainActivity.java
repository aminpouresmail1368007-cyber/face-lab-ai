package com.facelab.ai;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.security.MessageDigest;
import java.util.List;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceContour;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.FaceLandmark;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private static final int NATIVE_CAMERA_REQUEST = 7102;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 9, 12));

        webView = new WebView(this);
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep FACE LAB's
        // bottom navigation above the system navigation/gesture area.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottomInset);
            return insets;
        });
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(false);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.rgb(5, 9, 12));
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u == null ? "" : u.getScheme();
                return scheme != null && !scheme.equals("file") && !scheme.equals("about");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");

                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraOutputUri = createCameraOutputUri();
                if (cameraOutputUri != null) camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                if (params != null && params.isCaptureEnabled()) {
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                }

                try {
                    if (params != null && params.isCaptureEnabled() && cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(camera, FILE_CHOOSER_REQUEST);
                        return true;
                    }
                    Intent chooser = new Intent(Intent.ACTION_CHOOSER);
                    chooser.putExtra(Intent.EXTRA_INTENT, gallery);
                    chooser.putExtra(Intent.EXTRA_TITLE, "عکس گرفتن یا انتخاب از گالری");
                    if (cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "گالری یا دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private Uri createCameraOutputUri() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "FaceLab_Camera_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
            return getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == NATIVE_CAMERA_REQUEST) {
            if (resultCode == RESULT_OK && cameraOutputUri != null) {
                try (InputStream is = getContentResolver().openInputStream(cameraOutputUri); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                    if (is == null) throw new Exception("camera stream unavailable");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = is.read(buffer)) > 0) bos.write(buffer, 0, n);
                    String dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.FaceLabNativePhoto && window.FaceLabNativePhoto(" + JSONObject.quote(dataUrl) + ")", null);
                } catch (Exception e) {
                    Toast.makeText(this, "خواندن عکس دوربین انجام نشد", Toast.LENGTH_LONG).show();
                }
            }
            cameraOutputUri = null;
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
                if (cameraOutputUri != null) {
                    try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
                }
            } else if (cameraOutputUri != null) {
                result = new Uri[]{cameraOutputUri};
            }
        } else if (cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
        cameraOutputUri = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.FaceLab && FaceLab.handleAndroidBack ? FaceLab.handleAndroidBack() : 'not-handled'", value -> {
                if ("\"handled\"".equals(value)) return;
                if (webView.canGoBack()) webView.goBack();
                else MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String getVersion() { return "20.0"; }



        @JavascriptInterface
        public void detectFace(final String dataUrl) {
            if (dataUrl == null || !dataUrl.contains(",")) {
                sendFaceMapFailure("invalid-image");
                return;
            }
            new Thread(() -> {
                try {
                    String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) { sendFaceMapFailure("decode-failed"); return; }
                    final int iw = bitmap.getWidth(), ih = bitmap.getHeight();
                    InputImage image = InputImage.fromBitmap(bitmap, 0);
                    FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                            .build();
                    FaceDetector detector = FaceDetection.getClient(options);
                    detector.process(image)
                            .addOnSuccessListener(faces -> {
                                try {
                                    if (faces == null || faces.isEmpty()) { sendFaceMapFailure("no-face"); return; }
                                    Face best = faces.get(0);
                                    int bestArea = best.getBoundingBox().width() * best.getBoundingBox().height();
                                    for (Face f : faces) {
                                        int a = f.getBoundingBox().width() * f.getBoundingBox().height();
                                        if (a > bestArea) { best = f; bestArea = a; }
                                    }
                                    JSONObject out = new JSONObject();
                                    out.put("ok", true);
                                    out.put("width", iw); out.put("height", ih);
                                    Rect r = best.getBoundingBox();
                                    JSONObject box = new JSONObject();
                                    box.put("left", clamp01((double) r.left / iw));
                                    box.put("top", clamp01((double) r.top / ih));
                                    box.put("right", clamp01((double) r.right / iw));
                                    box.put("bottom", clamp01((double) r.bottom / ih));
                                    out.put("box", box);
                                    JSONArray points = new JSONArray();
                                    int[] lmTypes = new int[]{
                                            FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE,
                                            FaceLandmark.NOSE_BASE, FaceLandmark.MOUTH_LEFT,
                                            FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM,
                                            FaceLandmark.LEFT_EAR, FaceLandmark.RIGHT_EAR,
                                            FaceLandmark.LEFT_CHEEK, FaceLandmark.RIGHT_CHEEK
                                    };
                                    for (int t : lmTypes) {
                                        FaceLandmark lm = best.getLandmark(t);
                                        if (lm != null) points.put(normPoint(lm.getPosition(), iw, ih));
                                    }
                                    out.put("points", points);
                                    JSONArray contours = new JSONArray();
                                    int[] ct = new int[]{
                                            FaceContour.FACE, FaceContour.LEFT_EYEBROW_TOP, FaceContour.RIGHT_EYEBROW_TOP,
                                            FaceContour.LEFT_EYE, FaceContour.RIGHT_EYE, FaceContour.NOSE_BRIDGE,
                                            FaceContour.NOSE_BOTTOM, FaceContour.UPPER_LIP_TOP, FaceContour.LOWER_LIP_BOTTOM
                                    };
                                    for (int t : ct) {
                                        FaceContour fc = best.getContour(t);
                                        if (fc == null || fc.getPoints() == null || fc.getPoints().isEmpty()) continue;
                                        JSONArray arr = new JSONArray();
                                        for (PointF pt : fc.getPoints()) arr.put(normPoint(pt, iw, ih));
                                        contours.put(arr);
                                    }
                                    out.put("contours", contours);
                                    sendFaceMap(out.toString());
                                } catch (Exception e) { sendFaceMapFailure("map-error"); }
                                finally { detector.close(); }
                            })
                            .addOnFailureListener(e -> { detector.close(); sendFaceMapFailure("detector-failed"); });
                } catch (Exception e) { sendFaceMapFailure("decode-error"); }
            }).start();
        }

        private JSONObject normPoint(PointF p, int w, int h) throws Exception {
            JSONObject o = new JSONObject();
            o.put("x", clamp01(p.x / Math.max(1f, w)));
            o.put("y", clamp01(p.y / Math.max(1f, h)));
            return o;
        }

        private double clamp01(double v) { return Math.max(0.0, Math.min(1.0, v)); }

        private void sendFaceMap(String json) {
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(
                        "window.FaceLabFaceMap && window.FaceLabFaceMap(" + JSONObject.quote(json) + ")", null);
            });
        }

        private void sendFaceMapFailure(String reason) {
            try {
                JSONObject o = new JSONObject(); o.put("ok", false); o.put("reason", reason); sendFaceMap(o.toString());
            } catch (Exception ignored) { sendFaceMap("{\"ok\":false}"); }
        }

        @JavascriptInterface
        public String securityStatus() {
            JSONObject out = new JSONObject();
            try {
                String installer = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try { installer = getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName(); }
                    catch (Exception ignored) {}
                } else {
                    try { installer = getPackageManager().getInstallerPackageName(getPackageName()); }
                    catch (Exception ignored) {}
                }
                String digest = currentSignerSha256();
                String expected = "F6EA3826BE6C467DA8A907160A19031620ED3A8CAB906B0AA7626FB6021E73FC";
                boolean valid = BuildConfig.DEBUG || expected.equalsIgnoreCase(digest);
                out.put("signatureValid", valid);
                out.put("installer", installer == null || installer.isEmpty() ? "direct / review" : installer);
                out.put("storeInstall", "com.farsitel.bazaar".equals(installer) || "ir.mservices.market".equals(installer));
                out.put("debug", BuildConfig.DEBUG);
            } catch (Exception e) {
                try { out.put("signatureValid", BuildConfig.DEBUG); out.put("installer", "unknown"); } catch (Exception ignored) {}
            }
            return out.toString();
        }

        private String currentSignerSha256() throws Exception {
            PackageInfo pi;
            byte[] cert;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi.signingInfo;
                Signature[] sigs = si == null ? null : si.getApkContentsSigners();
                if (sigs == null || sigs.length == 0) return "";
                cert = sigs[0].toByteArray();
            } else {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "";
                cert = pi.signatures[0].toByteArray();
            }
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(cert);
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format(Locale.US, "%02X", b));
            return sb.toString();
        }

        @JavascriptInterface
        public void openFrontCamera() {
            runOnUiThread(() -> {
                try {
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraOutputUri = createCameraOutputUri();
                    if (cameraOutputUri == null) { Toast.makeText(MainActivity.this, "امکان ساخت فایل عکس وجود ندارد", Toast.LENGTH_LONG).show(); return; }
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                    if (camera.resolveActivity(getPackageManager()) != null) startActivityForResult(camera, NATIVE_CAMERA_REQUEST);
                    else Toast.makeText(MainActivity.this, "برنامه دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "باز کردن دوربین انجام نشد", Toast.LENGTH_LONG).show(); }
            });
        }

        @JavascriptInterface
        public void alertFeedback(final String level) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    boolean danger = "danger".equalsIgnoreCase(level);
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            if (danger) vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 70, 190}, -1));
                            else vibrator.vibrate(VibrationEffect.createOneShot(55L, 110));
                        } else {
                            if (danger) vibrator.vibrate(new long[]{0, 120, 70, 190}, -1);
                            else vibrator.vibrate(55L);
                        }
                    }
                    ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, danger ? 95 : 55);
                    if (danger) {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 160);
                        new android.os.Handler(getMainLooper()).postDelayed(() -> tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 190), 230);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 520);
                    } else {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 130);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public boolean saveBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri != null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "در Pictures/FaceLab ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "ذخیره انجام نشد", Toast.LENGTH_LONG).show());
            return false;
        }

        @JavascriptInterface
        public boolean shareBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri == null) return false;
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "اشتراک نتیجه FACE LAB"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "اشتراک‌گذاری در دسترس نیست", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        private Uri persistDataUrl(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.contains(",")) return null;
                String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = requestedName;
                if (safeName == null || safeName.trim().isEmpty()) {
                    safeName = "FaceLab_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
                }
                if (!safeName.toLowerCase(Locale.US).endsWith(".png")) safeName += ".png";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) return null;
                    os.write(bytes);
                    os.flush();
                }
                return uri;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
