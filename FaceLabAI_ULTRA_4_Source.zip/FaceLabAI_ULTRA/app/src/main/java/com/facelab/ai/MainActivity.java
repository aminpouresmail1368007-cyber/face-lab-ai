package com.facelab.ai;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 9, 12));

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(false);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.rgb(5, 9, 12));
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u == null ? "" : u.getScheme();
                return scheme != null && !scheme.equals("file") && !scheme.equals("about");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");

                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraOutputUri = createCameraOutputUri();
                if (cameraOutputUri != null) camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                if (params != null && params.isCaptureEnabled()) {
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                }

                try {
                    if (params != null && params.isCaptureEnabled() && cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(camera, FILE_CHOOSER_REQUEST);
                        return true;
                    }
                    Intent chooser = new Intent(Intent.ACTION_CHOOSER);
                    chooser.putExtra(Intent.EXTRA_INTENT, gallery);
                    chooser.putExtra(Intent.EXTRA_TITLE, "عکس گرفتن یا انتخاب از گالری");
                    if (cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "گالری یا دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private Uri createCameraOutputUri() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "FaceLab_Camera_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
            return getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
                if (cameraOutputUri != null) {
                    try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
                }
            } else if (cameraOutputUri != null) {
                result = new Uri[]{cameraOutputUri};
            }
        } else if (cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
        cameraOutputUri = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.FaceLab && FaceLab.handleAndroidBack ? FaceLab.handleAndroidBack() : 'not-handled'", value -> {
                if ("\"handled\"".equals(value)) return;
                if (webView.canGoBack()) webView.goBack();
                else MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String getVersion() { return "12.0"; }


        @JavascriptInterface
        public void alertFeedback(final String level) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    boolean danger = "danger".equalsIgnoreCase(level);
                    long duration = danger ? 130L : 55L;
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(VibrationEffect.createOneShot(duration, danger ? 220 : 100));
                        } else {
                            vibrator.vibrate(duration);
                        }
                    }
                    if (danger) {
                        ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75);
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 150);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 220);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public boolean saveBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri != null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "در Pictures/FaceLab ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "ذخیره انجام نشد", Toast.LENGTH_LONG).show());
            return false;
        }

        @JavascriptInterface
        public boolean shareBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri == null) return false;
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "اشتراک نتیجه FACE LAB"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "اشتراک‌گذاری در دسترس نیست", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        private Uri persistDataUrl(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.contains(",")) return null;
                String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = requestedName;
                if (safeName == null || safeName.trim().isEmpty()) {
                    safeName = "FaceLab_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
                }
                if (!safeName.toLowerCase(Locale.US).endsWith(".png")) safeName += ".png";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) return null;
                    os.write(bytes);
                    os.flush();
                }
                return uri;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
