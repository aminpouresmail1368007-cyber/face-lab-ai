-keepclassmembers class com.facelab.ai.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
