from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
required=['sim','academy','cases','progress','profile','regionbar','stage','faceImg','dynamicMap','faceMapBadge','zones','effects','targetPoint','faceLift','syringe','resFluid','barrelFluid','beforeImg','afterImg','compareSlider','face3DCanvas','academyList','caseGrid','galleryInput','lessonModal','securityStatus']
missing=[x for x in required if f'id=\"{x}\"' not in html]
if missing: raise SystemExit('Missing DOM id(s): '+', '.join(missing))
for token in ['FACE LAB PRO+ 20.0','INJECTION SIMULATION','window.FaceLabNativePhoto','window.FaceLabFaceMap','AndroidBridge.alertFeedback','injectNow','openCamera','Before / After Interactive','3D FACE VIEW','Security & License Readiness']:
    if token not in html: raise SystemExit('Missing feature token: '+token)
print('FACE LAB PRO+ 20.0 project check: OK')
