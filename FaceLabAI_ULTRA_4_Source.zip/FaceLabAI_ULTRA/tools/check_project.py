from pathlib import Path
from bs4 import BeautifulSoup
import re, sys
root = Path(__file__).resolve().parents[1]
html = root/'app/src/main/assets/index.html'
java = root/'app/src/main/java/com/facelab/ai/MainActivity.java'
manifest = root/'app/src/main/AndroidManifest.xml'
required=[html,java,manifest,root/'app/build.gradle',root/'.github/workflows/build-apk.yml']
missing=[str(p) for p in required if not p.exists()]
if missing:
    print('MISSING:',*missing,sep='\n'); sys.exit(1)
soup=BeautifulSoup(html.read_text(encoding='utf-8'),'html.parser')
ids={x.get('id') for x in soup.find_all(attrs={'id':True})}
for req in ['quickStart','galleryInput','cameraInput','baseCanvas','afterCanvas','saveBtn','shareBtn','selfTestBtn']:
    if req not in ids:
        print('Missing DOM id:',req);sys.exit(2)
text=java.read_text(encoding='utf-8')
for method in ['saveBase64Image','shareBase64Image','onShowFileChooser']:
    if method not in text:
        print('Missing Android integration:',method);sys.exit(3)
print('FACE LAB AI project structure: OK')
