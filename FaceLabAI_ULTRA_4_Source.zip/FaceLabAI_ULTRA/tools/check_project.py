from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
required=['home','studio','academy','profile','photoInput','photo','lessons','homeRing','saveCase','saveImage','shareImage','modal']
missing=[x for x in required if f'id="{x}"' not in html]
if missing:
    raise SystemExit('Missing DOM id(s): '+', '.join(missing))
for token in ['FACE LAB','8.0 COMMERCIAL','Visual Studio','Risk Awareness','Knowledge Check','AndroidBridge','Case Library']:
    if token not in html:
        raise SystemExit('Missing feature token: '+token)
print('FACE LAB 8.0 project check: OK')
