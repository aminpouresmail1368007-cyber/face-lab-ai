from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
required=['home','simulate','learn','lesson','safety','cases','progress','profile','photoInput','facePhoto','modal']
missing=[x for x in required if f'id="{x}"' not in html]
if missing:
    raise SystemExit('Missing DOM id(s): '+', '.join(missing))
for token in ['FACE LAB','10.0','آگاهی آناتومیک','آزمون مرور','AndroidBridge','کتابخانه کیس','شبیه‌سازی بصری','آکادمی FACE LAB']:
    if token not in html:
        raise SystemExit('Missing feature token: '+token)
print('FACE LAB 10.0 project check: OK')
