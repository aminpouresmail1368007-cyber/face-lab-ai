from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/"app/src/main/assets/index.html").read_text(encoding="utf-8")
required=["homePhoto","sculptViewer","sculptBase","sculptEdit","trainerStage","syringe","markContact","selfTestBtn","trainerPlunger","trainerInjectBtn","targetHud","resetTrainerFx"]
missing=[x for x in required if f'id="{x}"' not in html]
if missing:
    raise SystemExit("Missing DOM id(s): "+", ".join(missing))
for token in ["alertFeedback","riskAt","warpAt","Photo Sculpt","Needle Awareness Trainer","trainerWarpPreview","practiceAt"]:
    if token not in html:
        raise SystemExit("Missing feature token: "+token)
print("FACE LAB AI 7.2 project check: OK")
